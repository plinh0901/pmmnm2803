<?php get_header(); ?>

<div id="content">

	<?php
		
		get_template_part('content', 'post');
	
	?>
	
</div><!-- #content -->

<?php get_footer(); ?>